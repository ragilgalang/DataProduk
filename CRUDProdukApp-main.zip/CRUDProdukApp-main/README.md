Crud Android mobile with Firebase database
